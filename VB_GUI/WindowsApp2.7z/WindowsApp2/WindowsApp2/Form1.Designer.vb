﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.trkbarErrorBand = New System.Windows.Forms.TrackBar()
        Me.txtBoxErrorBand = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.trkBarFrequency = New System.Windows.Forms.TrackBar()
        Me.txtBoxFrequency = New System.Windows.Forms.TextBox()
        Me.txtBoxThresholdDB = New System.Windows.Forms.TextBox()
        Me.trkbarThreshold = New System.Windows.Forms.TrackBar()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtboxFFT = New System.Windows.Forms.TextBox()
        Me.trkbarFFT = New System.Windows.Forms.TrackBar()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtboxSample = New System.Windows.Forms.TextBox()
        Me.trkbarSample = New System.Windows.Forms.TrackBar()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtboxADC = New System.Windows.Forms.TextBox()
        Me.trkbarADC = New System.Windows.Forms.TrackBar()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtboxSolenoid = New System.Windows.Forms.TextBox()
        Me.trkbarSolenoid = New System.Windows.Forms.TrackBar()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtboxCycle = New System.Windows.Forms.TextBox()
        Me.trkbarCycle = New System.Windows.Forms.TrackBar()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtboxNumTrials = New System.Windows.Forms.TextBox()
        Me.trkbarNumTrials = New System.Windows.Forms.TrackBar()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.btnStop = New System.Windows.Forms.Button()
        Me.btnSend = New System.Windows.Forms.Button()
        Me.btnDisconnect = New System.Windows.Forms.Button()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.comboBoxPort = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblErrorDefault = New System.Windows.Forms.Label()
        Me.lblFrequency = New System.Windows.Forms.Label()
        Me.lblThreshold = New System.Windows.Forms.Label()
        Me.lblFFT = New System.Windows.Forms.Label()
        Me.lblSample = New System.Windows.Forms.Label()
        Me.lblADC = New System.Windows.Forms.Label()
        Me.lblSolenoid = New System.Windows.Forms.Label()
        Me.lblCycle = New System.Windows.Forms.Label()
        Me.lblNumTrials = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lblMin = New System.Windows.Forms.Label()
        Me.lblMax = New System.Windows.Forms.Label()
        Me.lblAvg = New System.Windows.Forms.Label()
        Me.lblStd = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        CType(Me.trkbarErrorBand, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkBarFrequency, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkbarThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkbarFFT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkbarSample, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkbarADC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkbarSolenoid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkbarCycle, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkbarNumTrials, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'trkbarErrorBand
        '
        Me.trkbarErrorBand.Location = New System.Drawing.Point(12, 40)
        Me.trkbarErrorBand.Maximum = 50
        Me.trkbarErrorBand.Minimum = 1
        Me.trkbarErrorBand.Name = "trkbarErrorBand"
        Me.trkbarErrorBand.Size = New System.Drawing.Size(260, 45)
        Me.trkbarErrorBand.TabIndex = 0
        Me.trkbarErrorBand.TickFrequency = 5
        Me.trkbarErrorBand.Value = 30
        '
        'txtBoxErrorBand
        '
        Me.txtBoxErrorBand.Location = New System.Drawing.Point(291, 45)
        Me.txtBoxErrorBand.Name = "txtBoxErrorBand"
        Me.txtBoxErrorBand.Size = New System.Drawing.Size(100, 20)
        Me.txtBoxErrorBand.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Error Band (Hz)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Peak Frequency"
        '
        'trkBarFrequency
        '
        Me.trkBarFrequency.Location = New System.Drawing.Point(12, 95)
        Me.trkBarFrequency.Maximum = 4000
        Me.trkBarFrequency.Minimum = 1
        Me.trkBarFrequency.Name = "trkBarFrequency"
        Me.trkBarFrequency.Size = New System.Drawing.Size(260, 45)
        Me.trkBarFrequency.TabIndex = 5
        Me.trkBarFrequency.TickFrequency = 250
        Me.trkBarFrequency.Value = 1935
        '
        'txtBoxFrequency
        '
        Me.txtBoxFrequency.Location = New System.Drawing.Point(291, 91)
        Me.txtBoxFrequency.Name = "txtBoxFrequency"
        Me.txtBoxFrequency.Size = New System.Drawing.Size(100, 20)
        Me.txtBoxFrequency.TabIndex = 6
        '
        'txtBoxThresholdDB
        '
        Me.txtBoxThresholdDB.Location = New System.Drawing.Point(291, 142)
        Me.txtBoxThresholdDB.Name = "txtBoxThresholdDB"
        Me.txtBoxThresholdDB.Size = New System.Drawing.Size(100, 20)
        Me.txtBoxThresholdDB.TabIndex = 9
        '
        'trkbarThreshold
        '
        Me.trkbarThreshold.Location = New System.Drawing.Point(12, 146)
        Me.trkbarThreshold.Maximum = 20
        Me.trkbarThreshold.Minimum = 1
        Me.trkbarThreshold.Name = "trkbarThreshold"
        Me.trkbarThreshold.Size = New System.Drawing.Size(260, 45)
        Me.trkbarThreshold.TabIndex = 8
        Me.trkbarThreshold.Value = 10
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 130)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Threshold DB"
        '
        'txtboxFFT
        '
        Me.txtboxFFT.Enabled = False
        Me.txtboxFFT.Location = New System.Drawing.Point(291, 193)
        Me.txtboxFFT.Name = "txtboxFFT"
        Me.txtboxFFT.Size = New System.Drawing.Size(100, 20)
        Me.txtboxFFT.TabIndex = 12
        '
        'trkbarFFT
        '
        Me.trkbarFFT.Enabled = False
        Me.trkbarFFT.Location = New System.Drawing.Point(12, 197)
        Me.trkbarFFT.Maximum = 1024
        Me.trkbarFFT.Minimum = 1
        Me.trkbarFFT.Name = "trkbarFFT"
        Me.trkbarFFT.Size = New System.Drawing.Size(260, 45)
        Me.trkbarFFT.TabIndex = 10
        Me.trkbarFFT.TickFrequency = 100
        Me.trkbarFFT.Value = 1024
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 181)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(215, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "FFT SIze (constant value unable to change)"
        '
        'txtboxSample
        '
        Me.txtboxSample.Enabled = False
        Me.txtboxSample.Location = New System.Drawing.Point(291, 244)
        Me.txtboxSample.Name = "txtboxSample"
        Me.txtboxSample.Size = New System.Drawing.Size(100, 20)
        Me.txtboxSample.TabIndex = 15
        '
        'trkbarSample
        '
        Me.trkbarSample.Enabled = False
        Me.trkbarSample.Location = New System.Drawing.Point(12, 248)
        Me.trkbarSample.Maximum = 20000
        Me.trkbarSample.Minimum = 1000
        Me.trkbarSample.Name = "trkbarSample"
        Me.trkbarSample.Size = New System.Drawing.Size(260, 45)
        Me.trkbarSample.TabIndex = 14
        Me.trkbarSample.TickFrequency = 1000
        Me.trkbarSample.Value = 6000
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(15, 232)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(180, 13)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Sample Rate Hz (Change in Arduino)"
        '
        'txtboxADC
        '
        Me.txtboxADC.Location = New System.Drawing.Point(291, 295)
        Me.txtboxADC.Name = "txtboxADC"
        Me.txtboxADC.Size = New System.Drawing.Size(100, 20)
        Me.txtboxADC.TabIndex = 18
        '
        'trkbarADC
        '
        Me.trkbarADC.Location = New System.Drawing.Point(12, 299)
        Me.trkbarADC.Maximum = 100
        Me.trkbarADC.Minimum = 1
        Me.trkbarADC.Name = "trkbarADC"
        Me.trkbarADC.Size = New System.Drawing.Size(260, 45)
        Me.trkbarADC.TabIndex = 17
        Me.trkbarADC.TickFrequency = 10
        Me.trkbarADC.Value = 100
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 283)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(80, 13)
        Me.Label6.TabIndex = 16
        Me.Label6.Text = "ADC Averaging"
        '
        'txtboxSolenoid
        '
        Me.txtboxSolenoid.Location = New System.Drawing.Point(291, 346)
        Me.txtboxSolenoid.Name = "txtboxSolenoid"
        Me.txtboxSolenoid.Size = New System.Drawing.Size(100, 20)
        Me.txtboxSolenoid.TabIndex = 21
        '
        'trkbarSolenoid
        '
        Me.trkbarSolenoid.Location = New System.Drawing.Point(12, 350)
        Me.trkbarSolenoid.Maximum = 100
        Me.trkbarSolenoid.Minimum = 1
        Me.trkbarSolenoid.Name = "trkbarSolenoid"
        Me.trkbarSolenoid.Size = New System.Drawing.Size(260, 45)
        Me.trkbarSolenoid.TabIndex = 20
        Me.trkbarSolenoid.TickFrequency = 10
        Me.trkbarSolenoid.Value = 6
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(15, 334)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(126, 13)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "Solenoid Energizing Time"
        '
        'txtboxCycle
        '
        Me.txtboxCycle.Location = New System.Drawing.Point(291, 397)
        Me.txtboxCycle.Name = "txtboxCycle"
        Me.txtboxCycle.Size = New System.Drawing.Size(100, 20)
        Me.txtboxCycle.TabIndex = 24
        '
        'trkbarCycle
        '
        Me.trkbarCycle.Location = New System.Drawing.Point(12, 401)
        Me.trkbarCycle.Maximum = 10000
        Me.trkbarCycle.Minimum = 1
        Me.trkbarCycle.Name = "trkbarCycle"
        Me.trkbarCycle.Size = New System.Drawing.Size(260, 45)
        Me.trkbarCycle.TabIndex = 23
        Me.trkbarCycle.TickFrequency = 1000
        Me.trkbarCycle.Value = 250
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 385)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 13)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "Cycle Time"
        '
        'txtboxNumTrials
        '
        Me.txtboxNumTrials.Location = New System.Drawing.Point(291, 448)
        Me.txtboxNumTrials.Name = "txtboxNumTrials"
        Me.txtboxNumTrials.Size = New System.Drawing.Size(100, 20)
        Me.txtboxNumTrials.TabIndex = 27
        '
        'trkbarNumTrials
        '
        Me.trkbarNumTrials.Location = New System.Drawing.Point(12, 452)
        Me.trkbarNumTrials.Maximum = 100
        Me.trkbarNumTrials.Minimum = 1
        Me.trkbarNumTrials.Name = "trkbarNumTrials"
        Me.trkbarNumTrials.Size = New System.Drawing.Size(260, 45)
        Me.trkbarNumTrials.TabIndex = 26
        Me.trkbarNumTrials.TickFrequency = 10
        Me.trkbarNumTrials.Value = 5
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(12, 436)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(84, 13)
        Me.Label9.TabIndex = 25
        Me.Label9.Text = "Number of Trials"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.btnStart)
        Me.Panel1.Controls.Add(Me.btnStop)
        Me.Panel1.Controls.Add(Me.btnSend)
        Me.Panel1.Controls.Add(Me.btnDisconnect)
        Me.Panel1.Controls.Add(Me.btnConnect)
        Me.Panel1.Controls.Add(Me.comboBoxPort)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Location = New System.Drawing.Point(491, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(355, 113)
        Me.Panel1.TabIndex = 28
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(245, 49)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 24)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Future Save"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(146, 79)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(75, 23)
        Me.btnStart.TabIndex = 7
        Me.btnStart.Text = "Start Test"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'btnStop
        '
        Me.btnStop.Location = New System.Drawing.Point(245, 79)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(75, 23)
        Me.btnStop.TabIndex = 6
        Me.btnStop.Text = "Stop"
        Me.btnStop.UseVisualStyleBackColor = True
        '
        'btnSend
        '
        Me.btnSend.Location = New System.Drawing.Point(146, 50)
        Me.btnSend.Name = "btnSend"
        Me.btnSend.Size = New System.Drawing.Size(75, 23)
        Me.btnSend.TabIndex = 5
        Me.btnSend.Text = "Send Values"
        Me.btnSend.UseVisualStyleBackColor = True
        '
        'btnDisconnect
        '
        Me.btnDisconnect.Enabled = False
        Me.btnDisconnect.Location = New System.Drawing.Point(245, 20)
        Me.btnDisconnect.Name = "btnDisconnect"
        Me.btnDisconnect.Size = New System.Drawing.Size(75, 23)
        Me.btnDisconnect.TabIndex = 4
        Me.btnDisconnect.Text = "Disconnect"
        Me.btnDisconnect.UseVisualStyleBackColor = True
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(146, 20)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(75, 23)
        Me.btnConnect.TabIndex = 3
        Me.btnConnect.Text = "Connect"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'comboBoxPort
        '
        Me.comboBoxPort.FormattingEnabled = True
        Me.comboBoxPort.Location = New System.Drawing.Point(3, 21)
        Me.comboBoxPort.Name = "comboBoxPort"
        Me.comboBoxPort.Size = New System.Drawing.Size(121, 21)
        Me.comboBoxPort.TabIndex = 2
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(4, 4)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(55, 13)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Serial Port"
        '
        'lblErrorDefault
        '
        Me.lblErrorDefault.AutoSize = True
        Me.lblErrorDefault.BackColor = System.Drawing.Color.Transparent
        Me.lblErrorDefault.Location = New System.Drawing.Point(418, 52)
        Me.lblErrorDefault.Name = "lblErrorDefault"
        Me.lblErrorDefault.Size = New System.Drawing.Size(34, 13)
        Me.lblErrorDefault.TabIndex = 29
        Me.lblErrorDefault.Text = "Value"
        '
        'lblFrequency
        '
        Me.lblFrequency.AutoSize = True
        Me.lblFrequency.Location = New System.Drawing.Point(418, 95)
        Me.lblFrequency.Name = "lblFrequency"
        Me.lblFrequency.Size = New System.Drawing.Size(34, 13)
        Me.lblFrequency.TabIndex = 30
        Me.lblFrequency.Text = "Value"
        '
        'lblThreshold
        '
        Me.lblThreshold.AutoSize = True
        Me.lblThreshold.Location = New System.Drawing.Point(418, 146)
        Me.lblThreshold.Name = "lblThreshold"
        Me.lblThreshold.Size = New System.Drawing.Size(34, 13)
        Me.lblThreshold.TabIndex = 31
        Me.lblThreshold.Text = "Value"
        '
        'lblFFT
        '
        Me.lblFFT.AutoSize = True
        Me.lblFFT.Enabled = False
        Me.lblFFT.Location = New System.Drawing.Point(418, 197)
        Me.lblFFT.Name = "lblFFT"
        Me.lblFFT.Size = New System.Drawing.Size(31, 13)
        Me.lblFFT.TabIndex = 32
        Me.lblFFT.Text = "1024"
        '
        'lblSample
        '
        Me.lblSample.AutoSize = True
        Me.lblSample.Location = New System.Drawing.Point(418, 251)
        Me.lblSample.Name = "lblSample"
        Me.lblSample.Size = New System.Drawing.Size(31, 13)
        Me.lblSample.TabIndex = 33
        Me.lblSample.Text = "6000"
        '
        'lblADC
        '
        Me.lblADC.AutoSize = True
        Me.lblADC.Location = New System.Drawing.Point(418, 299)
        Me.lblADC.Name = "lblADC"
        Me.lblADC.Size = New System.Drawing.Size(34, 13)
        Me.lblADC.TabIndex = 34
        Me.lblADC.Text = "Value"
        '
        'lblSolenoid
        '
        Me.lblSolenoid.AutoSize = True
        Me.lblSolenoid.Location = New System.Drawing.Point(418, 350)
        Me.lblSolenoid.Name = "lblSolenoid"
        Me.lblSolenoid.Size = New System.Drawing.Size(34, 13)
        Me.lblSolenoid.TabIndex = 35
        Me.lblSolenoid.Text = "Value"
        '
        'lblCycle
        '
        Me.lblCycle.AutoSize = True
        Me.lblCycle.Location = New System.Drawing.Point(418, 401)
        Me.lblCycle.Name = "lblCycle"
        Me.lblCycle.Size = New System.Drawing.Size(34, 13)
        Me.lblCycle.TabIndex = 36
        Me.lblCycle.Text = "Value"
        '
        'lblNumTrials
        '
        Me.lblNumTrials.AutoSize = True
        Me.lblNumTrials.Location = New System.Drawing.Point(418, 459)
        Me.lblNumTrials.Name = "lblNumTrials"
        Me.lblNumTrials.Size = New System.Drawing.Size(34, 13)
        Me.lblNumTrials.TabIndex = 37
        Me.lblNumTrials.Text = "Value"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel2.Location = New System.Drawing.Point(491, 146)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(355, 268)
        Me.Panel2.TabIndex = 38
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(498, 432)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(24, 13)
        Me.Label11.TabIndex = 39
        Me.Label11.Text = "Min"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(584, 432)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(27, 13)
        Me.Label12.TabIndex = 40
        Me.Label12.Text = "Max"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(667, 432)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(47, 13)
        Me.Label13.TabIndex = 41
        Me.Label13.Text = "Average"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(766, 432)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(35, 13)
        Me.Label14.TabIndex = 42
        Me.Label14.Text = "Stdev"
        '
        'lblMin
        '
        Me.lblMin.AutoSize = True
        Me.lblMin.Location = New System.Drawing.Point(501, 459)
        Me.lblMin.Name = "lblMin"
        Me.lblMin.Size = New System.Drawing.Size(34, 13)
        Me.lblMin.TabIndex = 43
        Me.lblMin.Text = "Value"
        '
        'lblMax
        '
        Me.lblMax.AutoSize = True
        Me.lblMax.Location = New System.Drawing.Point(584, 459)
        Me.lblMax.Name = "lblMax"
        Me.lblMax.Size = New System.Drawing.Size(34, 13)
        Me.lblMax.TabIndex = 44
        Me.lblMax.Text = "Value"
        '
        'lblAvg
        '
        Me.lblAvg.AutoSize = True
        Me.lblAvg.Location = New System.Drawing.Point(669, 459)
        Me.lblAvg.Name = "lblAvg"
        Me.lblAvg.Size = New System.Drawing.Size(34, 13)
        Me.lblAvg.TabIndex = 45
        Me.lblAvg.Text = "Value"
        '
        'lblStd
        '
        Me.lblStd.AutoSize = True
        Me.lblStd.Location = New System.Drawing.Point(766, 459)
        Me.lblStd.Name = "lblStd"
        Me.lblStd.Size = New System.Drawing.Size(34, 13)
        Me.lblStd.TabIndex = 46
        Me.lblStd.Text = "Value"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.Panel3.Location = New System.Drawing.Point(19, 503)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(827, 129)
        Me.Panel3.TabIndex = 47
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(882, 672)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.lblStd)
        Me.Controls.Add(Me.lblAvg)
        Me.Controls.Add(Me.lblMax)
        Me.Controls.Add(Me.lblMin)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.lblNumTrials)
        Me.Controls.Add(Me.lblCycle)
        Me.Controls.Add(Me.lblSolenoid)
        Me.Controls.Add(Me.lblADC)
        Me.Controls.Add(Me.lblSample)
        Me.Controls.Add(Me.lblFFT)
        Me.Controls.Add(Me.lblThreshold)
        Me.Controls.Add(Me.lblFrequency)
        Me.Controls.Add(Me.lblErrorDefault)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.txtboxNumTrials)
        Me.Controls.Add(Me.trkbarNumTrials)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtboxCycle)
        Me.Controls.Add(Me.trkbarCycle)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtboxSolenoid)
        Me.Controls.Add(Me.trkbarSolenoid)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtboxADC)
        Me.Controls.Add(Me.trkbarADC)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtboxSample)
        Me.Controls.Add(Me.trkbarSample)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtboxFFT)
        Me.Controls.Add(Me.trkbarFFT)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtBoxThresholdDB)
        Me.Controls.Add(Me.trkbarThreshold)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtBoxFrequency)
        Me.Controls.Add(Me.trkBarFrequency)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtBoxErrorBand)
        Me.Controls.Add(Me.trkbarErrorBand)
        Me.Name = "Form1"
        Me.RightToLeftLayout = True
        Me.Text = "Form1"
        CType(Me.trkbarErrorBand, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkBarFrequency, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkbarThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkbarFFT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkbarSample, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkbarADC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkbarSolenoid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkbarCycle, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkbarNumTrials, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents trkbarErrorBand As TrackBar
    Friend WithEvents txtBoxErrorBand As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents trkBarFrequency As TrackBar
    Friend WithEvents txtBoxFrequency As TextBox
    Friend WithEvents txtBoxThresholdDB As TextBox
    Friend WithEvents trkbarThreshold As TrackBar
    Friend WithEvents Label3 As Label
    Friend WithEvents txtboxFFT As TextBox
    Friend WithEvents trkbarFFT As TrackBar
    Friend WithEvents Label4 As Label
    Friend WithEvents txtboxSample As TextBox
    Friend WithEvents trkbarSample As TrackBar
    Friend WithEvents Label5 As Label
    Friend WithEvents txtboxADC As TextBox
    Friend WithEvents trkbarADC As TrackBar
    Friend WithEvents Label6 As Label
    Friend WithEvents txtboxSolenoid As TextBox
    Friend WithEvents trkbarSolenoid As TrackBar
    Friend WithEvents Label7 As Label
    Friend WithEvents txtboxCycle As TextBox
    Friend WithEvents trkbarCycle As TrackBar
    Friend WithEvents Label8 As Label
    Friend WithEvents txtboxNumTrials As TextBox
    Friend WithEvents trkbarNumTrials As TrackBar
    Friend WithEvents Label9 As Label
    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents Panel1 As Panel
    Friend WithEvents comboBoxPort As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents btnDisconnect As Button
    Friend WithEvents btnConnect As Button
    Friend WithEvents lblErrorDefault As Label
    Friend WithEvents lblFrequency As Label
    Friend WithEvents lblThreshold As Label
    Friend WithEvents lblFFT As Label
    Friend WithEvents lblSample As Label
    Friend WithEvents lblADC As Label
    Friend WithEvents lblSolenoid As Label
    Friend WithEvents lblCycle As Label
    Friend WithEvents lblNumTrials As Label
    Friend WithEvents btnStart As Button
    Friend WithEvents btnStop As Button
    Friend WithEvents btnSend As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents lblMin As Label
    Friend WithEvents lblMax As Label
    Friend WithEvents lblAvg As Label
    Friend WithEvents lblStd As Label
    Friend WithEvents Panel3 As Panel
End Class
