﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtBoxErrorBand.Text = trkbarErrorBand.Value
        txtBoxFrequency.Text = trkBarFrequency.Value
        txtboxFFT.Text = trkbarFFT.Value
        txtboxSample.Text = trkbarSample.Value
        txtboxADC.Text = trkbarADC.Value
        txtboxSolenoid.Text = trkbarSolenoid.Value
        txtboxCycle.Text = trkbarCycle.Value
        txtboxNumTrials.Text = trkbarNumTrials.Value
        txtBoxThresholdDB.Text = trkbarThreshold.Value


        'Populate the comboBox
        For i = 1 To 30
            comboBoxPort.Items.Add("COM" + i.ToString)
        Next
        comboBoxPort.Text = "COM27"

    End Sub

    Private Sub trkbarErrorBand_Scroll(sender As Object, e As EventArgs) Handles trkbarErrorBand.Scroll
        txtBoxErrorBand.Text = trkbarErrorBand.Value
    End Sub

    Private Sub txtBoxErrorBand_TextChanged(sender As Object, e As EventArgs) Handles txtBoxErrorBand.TextChanged
        Try
            trkbarErrorBand.Value = txtBoxErrorBand.Text
        Catch ex As Exception
        End Try
    End Sub

    Private Sub trkBarFrequency_Scroll(sender As Object, e As EventArgs) Handles trkBarFrequency.Scroll
        txtBoxFrequency.Text = trkBarFrequency.Value
    End Sub

    Private Sub txtBoxFrequency_TextChanged(sender As Object, e As EventArgs) Handles txtBoxFrequency.TextChanged
        Try
            trkBarFrequency.Value = txtBoxFrequency.Text
        Catch ex As Exception

        End Try

    End Sub

    Private Sub trkbarFFT_Scroll(sender As Object, e As EventArgs) Handles trkbarFFT.Scroll
        txtboxFFT.Text = trkbarFFT.Value
    End Sub

    Private Sub txtboxFFT_TextChanged(sender As Object, e As EventArgs) Handles txtboxFFT.TextChanged
        Try
            trkbarFFT.Value = txtboxFFT.Text
        Catch ex As Exception
        End Try
    End Sub

    Private Sub trkbarSample_Scroll(sender As Object, e As EventArgs) Handles trkbarSample.Scroll
        txtboxSample.Text = trkbarSample.Value
    End Sub

    Private Sub txtboxSample_TextChanged(sender As Object, e As EventArgs) Handles txtboxSample.TextChanged
        Try
            trkbarSample.Value = txtboxSample.Text
        Catch ex As Exception
        End Try
    End Sub

    Private Sub trkbarADC_Scroll(sender As Object, e As EventArgs) Handles trkbarADC.Scroll
        txtboxADC.Text = trkbarADC.Value
    End Sub

    Private Sub txtboxADC_TextChanged(sender As Object, e As EventArgs) Handles txtboxADC.TextChanged
        Try
            trkbarADC.Value = txtboxADC.Text
        Catch ex As Exception
        End Try
    End Sub

    Private Sub trkbarSolenoid_Scroll(sender As Object, e As EventArgs) Handles trkbarSolenoid.Scroll
        txtboxSolenoid.Text = trkbarSolenoid.Value

    End Sub

    Private Sub txtboxSolenoid_TextChanged(sender As Object, e As EventArgs) Handles txtboxSolenoid.TextChanged
        Try
            trkbarSolenoid.Value = txtboxSolenoid.Text
        Catch ex As Exception
        End Try
    End Sub

    Private Sub trkbarCycle_Scroll(sender As Object, e As EventArgs) Handles trkbarCycle.Scroll
        txtboxCycle.Text = trkbarCycle.Value
    End Sub

    Private Sub txtboxCycle_TextChanged(sender As Object, e As EventArgs) Handles txtboxCycle.TextChanged
        Try
            trkbarCycle.Value = txtboxCycle.Text
        Catch ex As Exception
        End Try
    End Sub

    Private Sub trkbarNumTrials_Scroll(sender As Object, e As EventArgs) Handles trkbarNumTrials.Scroll
        txtboxNumTrials.Text = trkbarNumTrials.Value

    End Sub

    Private Sub txtboxNumTrials_TextChanged(sender As Object, e As EventArgs) Handles txtboxNumTrials.TextChanged
        Try
            trkbarNumTrials.Value = txtboxNumTrials.Text
        Catch ex As Exception
        End Try
    End Sub

    Private Sub trkbarThreshold_Scroll(sender As Object, e As EventArgs) Handles trkbarThreshold.Scroll
        txtBoxThresholdDB.Text = trkbarThreshold.Value
    End Sub

    Private Sub txtBoxThresholdDB_TextChanged(sender As Object, e As EventArgs) Handles txtBoxThresholdDB.TextChanged
        Try
            trkbarThreshold.Value = txtBoxThresholdDB.Text
        Catch ex As Exception
        End Try
    End Sub

    Private Sub btnConnect_Click(sender As Object, e As EventArgs) Handles btnConnect.Click
        Dim connectionEstablished As Boolean
        connectionEstablished = False
        Dim var As String

        btnDisconnect.Enabled = True
        btnConnect.Enabled = False

        'Start serial connection
        With SerialPort1
            .PortName = comboBoxPort.Text
            .DataBits = 8
            .BaudRate = 32400
            .Handshake = IO.Ports.Handshake.None
            .StopBits = IO.Ports.StopBits.One
            .Parity = IO.Ports.Parity.None

            SerialPort1.Open()
        End With

        'Wait for a connection to be established
        'Send to Connection State
        SerialPort1.Write("C")
        var = SerialPort1.ReadLine()
        Debug.Print(var)
        PopulateData(var)
    End Sub


    Private Sub PopulateData(myString As String)
        'Breaks up the CSV line and populates the appropriate 
        Dim strings() As String
        strings = Split(myString, ",")
        lblErrorDefault.Text = strings(0)
        lblFrequency.Text = strings(1)
        lblThreshold.Text = strings(2)
        lblFFT.Text = strings(3)
        lblSample.Text = strings(4)
        lblADC.Text = strings(5)
        lblSolenoid.Text = strings(6)
        lblCycle.Text = strings(7)
        lblNumTrials.Text = strings(8)
    End Sub

    Private Function PackValues()

        Dim myString As String

        myString = txtBoxErrorBand.Text + "," + txtBoxFrequency.Text + "," + txtBoxThresholdDB.Text + "," + txtboxFFT.Text + "," + txtboxSample.Text + "," + txtboxADC.Text + "," + txtboxSolenoid.Text + "," + txtboxCycle.Text + "," + txtboxNumTrials.Text
        Debug.Print(myString)

        Return myString
    End Function



    Private Sub btnDisconnect_Click(sender As Object, e As EventArgs) Handles btnDisconnect.Click
        btnDisconnect.Enabled = False
        btnConnect.Enabled = True
    End Sub

    Private Sub btnSend_Click(sender As Object, e As EventArgs) Handles btnSend.Click
        Dim str As String
        Dim var As String
        str = PackValues()
        'Send U to 
        SerialPort1.Write("U")
        'Receive back update State
        Debug.Print(SerialPort1.ReadLine())
        'Write new values
        SerialPort1.WriteLine(str)
        'Echo the new updated values
        var = SerialPort1.ReadLine()
        PopulateData(var)
        Debug.Print(var)

    End Sub

    Private Sub btnGet_Click(sender As Object, e As EventArgs) Handles btnStop.Click
        Dim var As String
        SerialPort1.Write("s")
        var = SerialPort1.ReadLine()
        Debug.Print(var)

    End Sub

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        Dim window(Convert.ToInt16(lblNumTrials.Text) - 1) As Double
        Dim other(Convert.ToInt16(lblNumTrials.Text) - 1) As Double
        Dim xVal(Convert.ToInt16(lblNumTrials.Text) - 1) As Integer
        Dim counter As Integer = 0
        Dim str As String

        Dim strings() As String



        SerialPort1.Write("S")
        str = SerialPort1.ReadLine()
        str = str.Replace(vbCr, "")
        Debug.Print(str)
        Do While str.Substring(0, 1) <> "s"
            str = SerialPort1.ReadLine()
            str = str.Replace(vbCr, "")
            Debug.Print(str)
            If str <> "s" Then
                strings = Split(str, ",")
                If counter > 0 Then
                    Histogram(strings)
                End If
                xVal(counter) = counter
                    window(counter) = Convert.ToDouble(strings(0))
                    other(counter) = Convert.ToDouble(strings(1))
                    UpdateGraph(xVal, window, other, counter)

                    counter = counter + 1
                End If

                My.Application.DoEvents()

        Loop

        Debug.Print("Test Done; Calculating Statistics")
        calculateStatistics(window)

    End Sub

    Function Histogram(str() As String)
        Dim myPenWindow As New System.Drawing.Pen(Color.Red, 1)

        Dim myPenWindow1 As New System.Drawing.Pen(ColorTranslator.FromHtml("#0000FF"))


        Dim numBins As Integer = Convert.ToInt16(lblFFT.Text) / 2
        Dim xStepSize As Double = Panel3.Width / numBins
        Dim positions(numBins) As Double
        Dim xScaleFactor As Double
        Dim yScaleFactor As Double
        Dim yVal As Double
        Dim yValPrevious As Double
        Dim xVal As Single
        Dim xValPrev As Single
        xScaleFactor = Panel3.Width / numBins
        yScaleFactor = Panel3.Height / 100000
        Dim binMax As Integer = 0
        Dim binIndex As Integer

        For i As Integer = 3 To numBins


            yVal = Convert.ToSingle(20 * Math.Log10(Convert.ToDouble(str(i))))
            yValPrevious = Convert.ToSingle(20 * Math.Log10(Convert.ToDouble(str(i - 1))))
            'yVal = Convert.ToSingle(str(i))
            yValPrevious = Convert.ToSingle(str(i - 1))
            xVal = i
            xValPrev = i - 1

            Panel3.CreateGraphics.DrawLine(myPenWindow1, Convert.ToSingle(xScaleFactor) * Convert.ToSingle(xValPrev),
                                    Panel3.Height - Convert.ToSingle(yScaleFactor) * Convert.ToSingle(yValPrevious),
                                     Convert.ToSingle(xScaleFactor) * Convert.ToSingle(xVal),
                                     Panel3.Height - Convert.ToSingle(yScaleFactor) * Convert.ToSingle(yVal))

            If Convert.ToDouble(str(i)) > binMax Then
                binMax = Convert.ToDouble(str(i))
                binIndex = i
            End If



        Next
        'x'y'l'w


        Debug.Print(binIndex * 6000 / 1024)

    End Function



    Sub UpdateGraph(x() As Integer, y() As Double, y1() As Double, index As Integer)
        Dim myPenWindow As New System.Drawing.Pen(Color.Red, 1)
        Dim myPenOther As New System.Drawing.Pen(Color.Green, 1)

        Dim myBrush As New System.Drawing.SolidBrush(Color.Yellow)
        Dim idx As Integer
        Dim xScaleFactor As Double
        Dim yScaleFactor As Double



        Panel2.CreateGraphics.Clear(Color.Black)

        xScaleFactor = Panel2.Width / x.Length
        yScaleFactor = Panel2.Height / 100
        If index > 0 Then
            'Debug.Print(index)
            For idx = 1 To index

                Panel2.CreateGraphics.DrawLine(myPenWindow, Convert.ToSingle(xScaleFactor) * Convert.ToSingle(x(idx - 1)),
                                                     Panel2.Height - Convert.ToSingle(yScaleFactor) * Convert.ToSingle(y(idx - 1)),
                                                     Convert.ToSingle(xScaleFactor) * Convert.ToSingle(x(idx)),
                                                     Panel2.Height - Convert.ToSingle(yScaleFactor) * Convert.ToSingle(y(idx)))

                Panel2.CreateGraphics.DrawLine(myPenOther, Convert.ToSingle(xScaleFactor) * Convert.ToSingle(x(idx - 1)),
                                                     Panel2.Height - Convert.ToSingle(yScaleFactor) * Convert.ToSingle(y1(idx - 1)),
                                                     Convert.ToSingle(xScaleFactor) * Convert.ToSingle(x(idx)),
                                                     Panel2.Height - Convert.ToSingle(yScaleFactor) * Convert.ToSingle(y1(idx)))


                Panel2.CreateGraphics.FillRectangle(myBrush, Convert.ToSingle(xScaleFactor) * Convert.ToSingle(x(idx)) - 2,
                                                    Panel2.Height - Convert.ToSingle(yScaleFactor) * Convert.ToSingle(y(idx)) - 2,
                                                    5,
                                                    5)
            Next
        End If



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Histogram()


    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint
        Dim myPen As New System.Drawing.Pen(Color.Red, 1)

        'e.Graphics.DrawLine(myPen, 20, 30, 100, 100)

    End Sub



    Function calculateStatistics(y() As Double)
        'Calculate Max
        'Min
        Dim i As Integer
        Dim min As Double
        Dim max As Double
        Dim sum As Double = 0
        Dim avg As Double
        Dim sig As Double
        Dim summation As Double = 0

        min = 0
        max = 0

        For i = 1 To y.Length - 1
            If y(i) > max Then
                max = i
            End If
            If y(i) < min Then
                min = i
            End If

            sum = sum + i

        Next

        avg = sum / (y.Length - 1)

        For i = 1 To y.Length - 1
            summation = summation + ((y(i) - avg)) ^ 2
        Next

        sig = Math.Sqrt(summation / (y.Length - 1))


        'min = y(0)
        'max = y(0)

        'For i = 1 To y.Length - 1
        '    If y(i) > max Then
        '        max = y(i)
        '    End If
        '    If y(i) < min Then
        '        min = y(i)
        '    End If

        '    sum = sum + y(i)

        'Next

        'avg = sum / (y.Length - 1)

        'For i = 1 To y.Length - 1
        '    summation = summation + ((y(i) - avg)) ^ 2
        'Next

        'sig = Math.Sqrt(summation / (y.Length - 1))

        lblAvg.Text = avg
        lblMax.Text = max
        lblMin.Text = min
        lblStd.Text = sig



    End Function


End Class
